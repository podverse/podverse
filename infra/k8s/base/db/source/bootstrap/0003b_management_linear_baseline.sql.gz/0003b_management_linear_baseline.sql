-- GENERATED FILE (do not edit) — see scripts/database/generate-linear-baseline.sh and docs/operations/LINEAR-MIGRATIONS.md

-- Management database baseline (schema + migration-materialized data; applied as DB_MANAGEMENT_MIGRATOR_USER).

-- linear_migration_history data is appended deterministically from migration filenames + checksums.

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: nano_id_v2; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.nano_id_v2 AS character varying(15)
	CONSTRAINT nano_id_v2_len_check CHECK (((VALUE IS NULL) OR ((char_length((VALUE)::text) >= 9) AND (char_length((VALUE)::text) <= 15))));


--
-- Name: server_time_with_default; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.server_time_with_default AS timestamp without time zone DEFAULT now();


--
-- Name: varchar_email; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_email AS character varying(255)
	CONSTRAINT varchar_email_check CHECK (((VALUE)::text ~ '^.+@.+\..+$'::text));


--
-- Name: varchar_password; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_password AS character varying(60);


--
-- Name: set_updated_at_field(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_field() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_account (
    id integer NOT NULL,
    id_text public.nano_id_v2 NOT NULL,
    admin_account_role_id integer DEFAULT 2 NOT NULL,
    created_at public.server_time_with_default,
    updated_at public.server_time_with_default
);


--
-- Name: admin_account_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_account_credentials (
    id integer NOT NULL,
    admin_account_id integer NOT NULL,
    email public.varchar_email NOT NULL,
    password public.varchar_password NOT NULL
);


--
-- Name: admin_account_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_account_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_account_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_account_credentials_id_seq OWNED BY public.admin_account_credentials.id;


--
-- Name: admin_account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_account_id_seq OWNED BY public.admin_account.id;


--
-- Name: admin_account_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_account_permissions (
    id integer NOT NULL,
    admin_account_id integer NOT NULL,
    feeds_crud integer DEFAULT 0 NOT NULL,
    admins_crud integer DEFAULT 0 NOT NULL,
    stats_crud integer DEFAULT 0 NOT NULL,
    created_at public.server_time_with_default,
    updated_at public.server_time_with_default,
    feed_takedown_reasons_crud integer DEFAULT 0 NOT NULL,
    billing_prices_crud integer DEFAULT 0 NOT NULL,
    bucket_crud integer DEFAULT 0 NOT NULL,
    CONSTRAINT admin_account_permissions_admins_crud_check CHECK (((admins_crud >= 0) AND (admins_crud <= 15))),
    CONSTRAINT admin_account_permissions_bucket_crud_check CHECK (((bucket_crud >= 0) AND (bucket_crud <= 15))),
    CONSTRAINT admin_account_permissions_feed_takedown_reasons_crud_check CHECK (((feed_takedown_reasons_crud >= 0) AND (feed_takedown_reasons_crud <= 15))),
    CONSTRAINT admin_account_permissions_feeds_crud_check CHECK (((feeds_crud >= 0) AND (feeds_crud <= 15))),
    CONSTRAINT admin_account_permissions_stats_crud_check CHECK (((stats_crud >= 0) AND (stats_crud <= 15)))
);


--
-- Name: admin_account_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_account_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_account_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_account_permissions_id_seq OWNED BY public.admin_account_permissions.id;


--
-- Name: admin_account_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_account_role (
    id integer NOT NULL,
    role character varying(20) NOT NULL,
    created_at public.server_time_with_default,
    updated_at public.server_time_with_default,
    CONSTRAINT admin_account_role_role_check CHECK (((role)::text = ANY ((ARRAY['superuser'::character varying, 'admin'::character varying])::text[])))
);


--
-- Name: admin_account_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_account_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_account_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_account_role_id_seq OWNED BY public.admin_account_role.id;


--
-- Name: admin_account_set_password; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_account_set_password (
    id integer NOT NULL,
    admin_account_id integer NOT NULL,
    set_password_token character varying(36) NOT NULL,
    set_password_token_expires_at timestamp without time zone CONSTRAINT admin_account_set_password_set_password_token_expires__not_null NOT NULL
);


--
-- Name: admin_account_set_password_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_account_set_password_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_account_set_password_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_account_set_password_id_seq OWNED BY public.admin_account_set_password.id;


--
-- Name: database_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.database_audit_log (
    id bigint NOT NULL,
    admin_account_id integer NOT NULL,
    operation character varying(10) NOT NULL,
    table_name character varying(100) NOT NULL,
    row_id integer NOT NULL,
    before_snapshot jsonb,
    after_snapshot jsonb,
    request_id character varying(64),
    created_at public.server_time_with_default,
    CONSTRAINT database_audit_log_operation_check CHECK (((operation)::text = ANY ((ARRAY['create'::character varying, 'update'::character varying, 'delete'::character varying])::text[])))
);


--
-- Name: database_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.database_audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: database_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.database_audit_log_id_seq OWNED BY public.database_audit_log.id;


--
-- Name: linear_migration_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linear_migration_history (
    id integer NOT NULL,
    migration_filename character varying(255) NOT NULL,
    migration_checksum character varying(64) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.linear_migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.linear_migration_history_id_seq OWNED BY public.linear_migration_history.id;


--
-- Name: admin_account id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account ALTER COLUMN id SET DEFAULT nextval('public.admin_account_id_seq'::regclass);


--
-- Name: admin_account_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_credentials ALTER COLUMN id SET DEFAULT nextval('public.admin_account_credentials_id_seq'::regclass);


--
-- Name: admin_account_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_account_permissions_id_seq'::regclass);


--
-- Name: admin_account_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_role ALTER COLUMN id SET DEFAULT nextval('public.admin_account_role_id_seq'::regclass);


--
-- Name: admin_account_set_password id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_set_password ALTER COLUMN id SET DEFAULT nextval('public.admin_account_set_password_id_seq'::regclass);


--
-- Name: database_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.database_audit_log ALTER COLUMN id SET DEFAULT nextval('public.database_audit_log_id_seq'::regclass);


--
-- Name: linear_migration_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history ALTER COLUMN id SET DEFAULT nextval('public.linear_migration_history_id_seq'::regclass);


--
-- Data for Name: admin_account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_account (id, id_text, admin_account_role_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_account_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_account_credentials (id, admin_account_id, email, password) FROM stdin;
\.


--
-- Data for Name: admin_account_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_account_permissions (id, admin_account_id, feeds_crud, admins_crud, stats_crud, created_at, updated_at, feed_takedown_reasons_crud, billing_prices_crud, bucket_crud) FROM stdin;
\.


--
-- Data for Name: admin_account_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_account_role (id, role, created_at, updated_at) FROM stdin;
1	superuser	2000-01-01 00:00:00	2000-01-01 00:00:00
2	admin	2000-01-01 00:00:00	2000-01-01 00:00:00
\.


--
-- Data for Name: admin_account_set_password; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_account_set_password (id, admin_account_id, set_password_token, set_password_token_expires_at) FROM stdin;
\.


--
-- Data for Name: database_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.database_audit_log (id, admin_account_id, operation, table_name, row_id, before_snapshot, after_snapshot, request_id, created_at) FROM stdin;
\.


--
-- Name: admin_account_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_account_credentials_id_seq', 1, false);


--
-- Name: admin_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_account_id_seq', 1, false);


--
-- Name: admin_account_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_account_permissions_id_seq', 1, false);


--
-- Name: admin_account_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_account_role_id_seq', 1, false);


--
-- Name: admin_account_set_password_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_account_set_password_id_seq', 1, false);


--
-- Name: database_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.database_audit_log_id_seq', 1, false);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.linear_migration_history_id_seq', 8, true);


--
-- Name: admin_account_credentials admin_account_credentials_admin_account_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_credentials
    ADD CONSTRAINT admin_account_credentials_admin_account_id_key UNIQUE (admin_account_id);


--
-- Name: admin_account_credentials admin_account_credentials_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_credentials
    ADD CONSTRAINT admin_account_credentials_email_key UNIQUE (email);


--
-- Name: admin_account_credentials admin_account_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_credentials
    ADD CONSTRAINT admin_account_credentials_pkey PRIMARY KEY (id);


--
-- Name: admin_account admin_account_id_text_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account
    ADD CONSTRAINT admin_account_id_text_key UNIQUE (id_text);


--
-- Name: admin_account_permissions admin_account_permissions_admin_account_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_permissions
    ADD CONSTRAINT admin_account_permissions_admin_account_id_key UNIQUE (admin_account_id);


--
-- Name: admin_account_permissions admin_account_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_permissions
    ADD CONSTRAINT admin_account_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_account admin_account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account
    ADD CONSTRAINT admin_account_pkey PRIMARY KEY (id);


--
-- Name: admin_account_role admin_account_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_role
    ADD CONSTRAINT admin_account_role_pkey PRIMARY KEY (id);


--
-- Name: admin_account_role admin_account_role_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_role
    ADD CONSTRAINT admin_account_role_role_key UNIQUE (role);


--
-- Name: admin_account_set_password admin_account_set_password_admin_account_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_set_password
    ADD CONSTRAINT admin_account_set_password_admin_account_id_key UNIQUE (admin_account_id);


--
-- Name: admin_account_set_password admin_account_set_password_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_set_password
    ADD CONSTRAINT admin_account_set_password_pkey PRIMARY KEY (id);


--
-- Name: database_audit_log database_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.database_audit_log
    ADD CONSTRAINT database_audit_log_pkey PRIMARY KEY (id);


--
-- Name: linear_migration_history linear_migration_history_migration_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_migration_filename_key UNIQUE (migration_filename);


--
-- Name: linear_migration_history linear_migration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_account_admin_account_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_account_admin_account_role_id ON public.admin_account USING btree (admin_account_role_id);


--
-- Name: idx_admin_account_credentials_admin_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_account_credentials_admin_account_id ON public.admin_account_credentials USING btree (admin_account_id);


--
-- Name: idx_admin_account_permissions_admin_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_account_permissions_admin_account_id ON public.admin_account_permissions USING btree (admin_account_id);


--
-- Name: idx_admin_account_set_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_admin_account_set_password_token ON public.admin_account_set_password USING btree (set_password_token);


--
-- Name: idx_database_audit_log_admin_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_database_audit_log_admin_account_id ON public.database_audit_log USING btree (admin_account_id);


--
-- Name: idx_database_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_database_audit_log_created_at ON public.database_audit_log USING btree (created_at);


--
-- Name: idx_database_audit_log_table_name_row_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_database_audit_log_table_name_row_id ON public.database_audit_log USING btree (table_name, row_id);


--
-- Name: idx_linear_migration_history_applied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_linear_migration_history_applied_at ON public.linear_migration_history USING btree (applied_at DESC);


--
-- Name: admin_account set_updated_at_admin_account; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_admin_account BEFORE UPDATE ON public.admin_account FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: admin_account_permissions set_updated_at_admin_account_permissions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_admin_account_permissions BEFORE UPDATE ON public.admin_account_permissions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: admin_account_role set_updated_at_admin_account_role; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_admin_account_role BEFORE UPDATE ON public.admin_account_role FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: admin_account admin_account_admin_account_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account
    ADD CONSTRAINT admin_account_admin_account_role_id_fkey FOREIGN KEY (admin_account_role_id) REFERENCES public.admin_account_role(id);


--
-- Name: admin_account_credentials admin_account_credentials_admin_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_credentials
    ADD CONSTRAINT admin_account_credentials_admin_account_id_fkey FOREIGN KEY (admin_account_id) REFERENCES public.admin_account(id) ON DELETE CASCADE;


--
-- Name: admin_account_permissions admin_account_permissions_admin_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_permissions
    ADD CONSTRAINT admin_account_permissions_admin_account_id_fkey FOREIGN KEY (admin_account_id) REFERENCES public.admin_account(id) ON DELETE CASCADE;


--
-- Name: admin_account_set_password admin_account_set_password_admin_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_account_set_password
    ADD CONSTRAINT admin_account_set_password_admin_account_id_fkey FOREIGN KEY (admin_account_id) REFERENCES public.admin_account(id) ON DELETE CASCADE;


--
-- Name: database_audit_log database_audit_log_admin_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.database_audit_log
    ADD CONSTRAINT database_audit_log_admin_account_id_fkey FOREIGN KEY (admin_account_id) REFERENCES public.admin_account(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO podverse_management_migrator;
GRANT USAGE ON SCHEMA public TO podverse_management_read_write;
GRANT USAGE ON SCHEMA public TO podverse_management_read;


--
-- Name: TABLE admin_account; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_account TO podverse_management_read_write;
GRANT SELECT ON TABLE public.admin_account TO podverse_management_read;


--
-- Name: TABLE admin_account_credentials; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_account_credentials TO podverse_management_read_write;
GRANT SELECT ON TABLE public.admin_account_credentials TO podverse_management_read;


--
-- Name: SEQUENCE admin_account_credentials_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.admin_account_credentials_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.admin_account_credentials_id_seq TO podverse_management_read;


--
-- Name: SEQUENCE admin_account_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.admin_account_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.admin_account_id_seq TO podverse_management_read;


--
-- Name: TABLE admin_account_permissions; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_account_permissions TO podverse_management_read_write;
GRANT SELECT ON TABLE public.admin_account_permissions TO podverse_management_read;


--
-- Name: SEQUENCE admin_account_permissions_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.admin_account_permissions_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.admin_account_permissions_id_seq TO podverse_management_read;


--
-- Name: TABLE admin_account_role; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_account_role TO podverse_management_read_write;
GRANT SELECT ON TABLE public.admin_account_role TO podverse_management_read;


--
-- Name: SEQUENCE admin_account_role_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.admin_account_role_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.admin_account_role_id_seq TO podverse_management_read;


--
-- Name: TABLE admin_account_set_password; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_account_set_password TO podverse_management_read_write;
GRANT SELECT ON TABLE public.admin_account_set_password TO podverse_management_read;


--
-- Name: SEQUENCE admin_account_set_password_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.admin_account_set_password_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.admin_account_set_password_id_seq TO podverse_management_read;


--
-- Name: TABLE database_audit_log; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.database_audit_log TO podverse_management_read_write;
GRANT SELECT ON TABLE public.database_audit_log TO podverse_management_read;


--
-- Name: SEQUENCE database_audit_log_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.database_audit_log_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.database_audit_log_id_seq TO podverse_management_read;


--
-- Name: TABLE linear_migration_history; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.linear_migration_history TO podverse_management_read_write;
GRANT SELECT ON TABLE public.linear_migration_history TO podverse_management_read;


--
-- Name: SEQUENCE linear_migration_history_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.linear_migration_history_id_seq TO podverse_management_read_write;
GRANT SELECT ON SEQUENCE public.linear_migration_history_id_seq TO podverse_management_read;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE podverse_management_migrator IN SCHEMA public GRANT ALL ON SEQUENCES TO podverse_management_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE podverse_management_migrator IN SCHEMA public GRANT SELECT ON SEQUENCES TO podverse_management_read;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE podverse_management_migrator IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO podverse_management_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE podverse_management_migrator IN SCHEMA public GRANT SELECT ON TABLES TO podverse_management_read;


--
-- PostgreSQL database dump complete
--




-- Management database linear migration history
INSERT INTO public.linear_migration_history (migration_filename, migration_checksum) VALUES
  ('0000_init_helpers.sql', '2e400ab226fd8bafe0380d92a8341c5a9d4fc8b2b79f027d6db214580aa18b82'),
  ('0001_init_admin_accounts.sql', '2fa889c0997c511688a3ef59e95faf8f9ae8c82094663607e3c158bbb2ea2c49'),
  ('0002_admin_account_permissions.sql', '4a4b47174ebd5461806e7cc5283380211de6330ab50d8fe838ddacc622dd8ba8'),
  ('0003_database_audit_log.sql', '11463218c192200aa91ce78003dfda58f730eba9b87e63c2d1bd3ca36a8e90ea'),
  ('0004_feed_takedown_reason_permissions.sql', '6238020dfb60f59a7d985783883bb4ddf7a7ba7fe69649571468128f4d336a90'),
  ('0005_billing_prices_permissions.sql', 'bce995e6638ad3bb31143638d9c49d9f5db9ff8a058f94faa1fd1ef937d5224c'),
  ('0006_bucket_permissions.sql', '645085d8d3950d97a5df0c80d580aa20525c4cd9d6b0927cb268b3f8a16702e2'),
  ('0007_admin_account_set_password.sql', '989438b4ef08c190478662b653f1ee1951083a67275178ebccee9caa8f2e5b7f')
ON CONFLICT (migration_filename) DO NOTHING;
